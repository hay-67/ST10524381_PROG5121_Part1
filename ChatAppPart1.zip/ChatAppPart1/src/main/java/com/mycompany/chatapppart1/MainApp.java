/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class MainApp {
     public static void main(String[] args) {

// Scanner reads user input
Scanner input = new Scanner(System.in);

// Access login object methods
Login login = new Login();

// --- REGISTRATION SECTION ---
System.out.println(" === USER REGISTRATION === ");

// Get User Details
System.out.print("Enter a username: ");
String username = input.nextLine();

System.out.print("Enter a password: ");
String password = input.nextLine();

System.out.print("Enter your South African phone number (+27 ... ): ");
String phone = input.nextLine();

// Register User and Store Response
String response = login.registerUser(username, password, phone);

// Display registration result
System.out.println(response);

// --- LOGIN SECTION --
System.out.println("\n === USER LOGIN === ");

// Get Login Details
System.out.print("Enter your username: ");
String loginUsername = input.nextLine();

System.out.print("Enter your password: ");
String loginPassword = input.nextLine();

// Check if login details are correct
boolean loggedIn = login.loginUser(loginUsername, loginPassword);

// Display Login message
String loginMessage = login.returnLoginStatus(loggedIn);
System.out.println(loginMessage);

}
    
}
